import 'package:flutter/material.dart';

class AppColors {
  static const primary = Color(0xFF1D9E75);
  static const secondary = Color(0xFF0F3E2E);

  static const textPrimary = Color(0xFF0F172A);
  static const textSecondary = Color(0xFF64748B);

  static const bgLight = Color(0xFFF8F9FC);

  static const urgent = Color(0xFFE24B4A);
}