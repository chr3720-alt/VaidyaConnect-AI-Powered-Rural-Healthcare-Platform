import 'package:flutter/material.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  Widget buildCard(
      IconData icon,
      String title) {
    return Card(
      child: Padding(
        padding:
            const EdgeInsets.all(20),

        child: Column(
          children: [
            Icon(icon,
                size: 40,
                color: Colors.teal),

            const SizedBox(height: 10),

            Text(title),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title:
            const Text("Rural Health"),
      ),

      body: Padding(
        padding:
            const EdgeInsets.all(16),

        child: GridView.count(
          crossAxisCount: 2,

          crossAxisSpacing: 12,
          mainAxisSpacing: 12,

          children: [
            buildCard(
                Icons.upload,
                "Upload Case"),

            buildCard(
                Icons.chat,
                "Chat Doctor"),

            buildCard(
                Icons.history,
                "History"),

            buildCard(
                Icons.local_hospital,
                "Clinics"),
          ],
        ),
      ),
    );
  }
}